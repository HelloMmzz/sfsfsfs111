# ���� AES ��Կ
function Generate-Key {
    param (
        [string]$Password
    )

    $salt = [byte[]] (1..16)
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($salt)
    $keyGenerator = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($Password, $salt, 10000)
    $key = $keyGenerator.GetBytes(32) # AES 256-bit key
    $iv = $keyGenerator.GetBytes(16)  # AES 128-bit IV
    return [PSCustomObject]@{ Key = $key; IV = $iv; Salt = $salt }
}

# �����ļ�
function Encrypt-File {
    param (
        [string]$FilePath,
        [string]$Password
    )

    $keyInfo = Generate-Key -Password $Password
    $key = $keyInfo.Key
    $iv = $keyInfo.IV
    $salt = $keyInfo.Salt

    $aes = [System.Security.Cryptography.Aes]::Create()
    $aes.Key = $key
    $aes.IV = $iv
    $aes.Mode = [System.Security.Cryptography.CipherMode]::CBC
    $aes.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7

    $encryptor = $aes.CreateEncryptor($aes.Key, $aes.IV)
    $fileContent = [System.IO.File]::ReadAllBytes($FilePath)
    $encryptedContent = $encryptor.TransformFinalBlock($fileContent, 0, $fileContent.Length)

    $outputFile = "$FilePath.enc"
    [System.IO.File]::WriteAllBytes($outputFile, $salt + $iv + $encryptedContent)
    Write-Host "File encrypted to: $outputFile"
}

# ָ��·��������
$files = Get-ChildItem -Path "E:\test\PowerUp.ps1" -Recurse
$Password = Read-Host -AsSecureString "Enter encryption password"
$PasswordPlain = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Password))

foreach ($file in $files) {
    if (-not $file.PSIsContainer) {
        Encrypt-File -FilePath $file.FullName -Password $PasswordPlain
    }
}
